## External Data Sources
We know they don't all line up... in the event of a variation between standards the main LFRic field should be defined using the format of data we would like and additional standards should be created as derived diagnostic fields (e.g. sea ice cover - units are % in CMIP, 1 in CF so derived field can do the fraction/percentage conversion)
###CMIP6
_cmip6.json_
file exported using http://clipc-services.ceda.ac.uk/dreq/mipVars.html on 10/12/2020

###CF
_cf-standard-name-table.xml_
downloaded from https://cfconventions.org/Data/cf-standard-names/75/src/cf-standard-name-table.xml on 14/12/2020
