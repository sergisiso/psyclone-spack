#!/usr/bin/env python
##############################################################################
# (C) British Crown Copyright 2020 Met Office.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Rose. If not, see <http://www.gnu.org/licenses/>.
##############################################################################
"""This module contains functionality for writing LFRic meta data to disk as a
rose-meta.conf file"""
import logging
import os
from textwrap import wrap
from typing import Dict, List

LOGGER = logging.getLogger("lfric_meta_data_parser")


def create_rose_meta(meta_data: Dict, file_name: str):
    """
    Creates a rose_meta.conf file using the supplied meta data
    :param meta_data: Dict containing all meta data
    :param file_name: The name of the file that the meta data will be
    written to
    :return rose_meta: The rose-meta file as a string, ready to be written to
    disk
    """
    # pylint: disable=too-many-branches
    LOGGER.info("Creating %s.conf", file_name)
    rose_meta = ""

    rose_meta += """
[field_config]
title=LFRic Field Configuration
"""
    # pylint: disable=too-many-nested-blocks
    for section in meta_data["sections"].values():
        rose_meta += f"""
[field_config:{section.name}]
title={section.title}"""

        for group in section.groups.values():
            rose_meta += f"""
[field_config:{section.name}:{group.name}]
title={group.title}"""
            model_levels = {}
            for field in group.fields.values():
                if field.vertical_dimension:
                    if "top_arg" in field.vertical_dimension:
                        model_levels[field.vertical_dimension["top_arg"]]\
                            = None
                    if "bottom_arg" in field.vertical_dimension:
                        model_levels[field.vertical_dimension["bottom_arg"]]\
                            = None
            if model_levels:
                rose_meta += f"""
[field_config:{section.name}:{group.name}=model_levels_for_group]
title=Model Levels used by this group
description=Vertical dimensions must define these levels to be valid
values=
"""
                for model_level in model_levels:
                    rose_meta += "            " + model_level + os.linesep

                rose_meta += """
sort-key=01
compulsory=true
"""
                rose_meta += f"""
[field_config:{section.name}:{group.name}=vertical_dimension_for_group]
title=Vertical dimension used by this group
description=If you have edited the vertical dimensions please restart the GUI
            to pick up the changes to the rose-app.conf file
widget[rose-config-edit]=vertical_dimension_choice.VertDimWidget
sort-key=02
compulsory=true
"""

            for field in group.fields.values():
                rose_meta += f"""
[field_config:{section.name}:{group.name}={field.unique_id}]
type=boolean
title=Enable {field.item_title}
trigger=field_config:{section.name}:{group.name}={field.unique_id}{
                field.trigger}
help=Unit of Measure: {field.units}
    =Function Space: {field.function_space}
    =Data type: {field.data_type}
    =Time step: {field.time_step}
    =Interpolation: {field.recommended_interpolation}
"""
                if field.vertical_dimension:
                    attribute_string = f"    =vertical_dimension:{os.linesep}"
                    for key, value in field.vertical_dimension.items():
                        if key == "top_arg":
                            key = "top_level"
                        if key == "bottom_arg":
                            key = "bottom_level"
                        attribute_string += f"       ={key}: " \
                                            f"{str(value)}{os.linesep}"

                    rose_meta += attribute_string

                if field.synonyms:
                    attribute_string = f"    =Synonyms:{os.linesep}"
                    for key, values in field.synonyms.items():
                        for value in values:
                            attribute_string += f"    =    {key.value}: " \
                                                f"{str(value)}{os.linesep}"

                    rose_meta += attribute_string

                if field.non_spatial_dimension:
                    attribute_string = f"    =Required non-spatial " \
                                       f"dimensions:{os.linesep}"
                    for dimension in field.non_spatial_dimension.values():
                        attribute_string += f"""    =    {dimension["name"]}"""

                    rose_meta += attribute_string

                    # Formats the description, adding newlines every 100 chars
                line_sep = "\n           "
                rose_meta += f"""
description={line_sep.join(wrap(field.description,width=100))}
           =For more information on {field.item_title}, see the help text
"""

                rose_meta += f"""
[field_config:{section.name}:{group.name}={field.unique_id}__checksum]
type=boolean
title=Enable Checksum for {field.item_title}
"""

    rose_meta = add_file_meta(meta_data, rose_meta)
    rose_meta = add_vertical_meta(rose_meta,
                                  meta_data["standard_level_markers"])
    rose_meta = add_non_spatial_dims_meta(meta_data["non_spatial_dimensions"],
                                          rose_meta)

    return rose_meta


def add_file_meta(meta_data: Dict, rose_meta: str) -> str:
    """Adds meta data for file output in rose.
    :param meta_data: Dict containing parsed meta data
    :param rose_meta: String that the file output data will be appended to
    :return rose_meta: String with file output data appended to it"""

    values_list = []
    titles_list = []

    for section in meta_data["sections"].values():
        for group in section.groups.values():
            for field in group.fields.values():

                values_list.append(field.unique_id)
                titles_list.append(
                    section.title + ": " + group.title +
                    ": " + field.item_title)

    values = ', '.join(values_list)
    titles = '", "'.join(titles_list)

    rose_meta += f"""[output_stream]
duplicate=true
macro=add_section.AddField, add_section.AddStream
title=Output Streams

[output_stream=name]
type=character

[output_stream=timestep]
type=character

[output_stream:field]
duplicate=true
macro=add_section.AddField
title=Fields

[output_stream:field=id]
values={values}
value-titles="{titles}"

[output_stream:field=temporal]
values=instant,average,accumulate,minimum,maximum,once
"""
    return rose_meta


def add_vertical_meta(rose_meta: str, levels: List) -> str:
    """Adds data about vertical dimensions. Currently static, will be further
    developed in the future
    :param rose_meta: String that the vertical dimension data will be appended
    to
    :param levels: A List of model levels
    :return rose_meta: String with vertical dimension data appended to it"""
    rose_meta += """
[vertical_dimension]
duplicate=true
title=Vertical Dimension

[vertical_dimension=name]
title=Name
description=Name of the vertical dimension
help=The name used to identify this vertical dimension when associating a field
     with it in Rose
type=character
compulsory=true
fail-if=len(this) == 0 # Name must be specified
sort-key=01

[vertical_dimension=primary_axis]
title=Primary axis
description=Does this dimension define the vertical extrusion in LFRic
help=Should the LFRic vertical extrusion be based on this dimension
    =If true then the specification method should be generated
    =The LFRic extrusion namelist can then be updated with the given parameters
    =Only one dimension should be set to true
values=true,false
compulsory=true
fail-if=this == 'true' and vertical_dimension=specification_method == 'manual'
       =# Primary axis must have generated as specification method
sort-key=02

[vertical_dimension=specification_method]
title=Specification method
description=Method for specifying the dimension level definition
help=Whether the vertical dimension is specified by parameters used to generate
     it in lFRic, or by the height of each level being defined in Rose
values=generated,manual
trigger=vertical_dimension=extrusion_method: generated;
       =vertical_dimension=domain_top: generated;
       =vertical_dimension=level_definition: manual;
compulsory=true
sort-key=03

[vertical_dimension=number_of_layers]
compulsory=true
description=Number of layers in the vertical
fail-if=this < 1 ;
help=Setting for number of layers of 3D-mesh in vertical.
range=1:
sort-key=04
title=Number of layers
type=integer

[vertical_dimension=domain_top]
compulsory=true
description=Domain height [m]
fail-if=this < 0.0 ;
help=Height of the model domain from a flat planet surface.
    =Height of planet surface taken as:
    = * For Cartesian domain: 0m
    = * For Spherical domain: namelist:planet=radius
range=0.0:
sort-key=05
title=Domain top
type=real

[vertical_dimension=extrusion_method]
compulsory=true
description=Method for generating eta coordinate
fail-if=this == 'um_L38_29t_9s_40km'  and vertical_dimension=number_of_layers != 38 ;
       =this == 'um_L70_50t_20s_80km' and vertical_dimension=number_of_layers != 70 ;
       =this == 'um_L85_50t_35s_85km' and vertical_dimension=number_of_layers != 85 ;
help=Available extrusion methods are (\\f$n$ is number of layers):
    =1) Uniform eta spacing (\\f$\\frac{k}{n}\\f$);
    =2) Quadratic eta spacing (\\f$\\frac{k}{n}^2\\f$);
    =3) Geometric eta spacing (\\f$d\\eta = \\frac{(s - 1)}{(s^{n} - 1)}$)
    =    with stretching factor prescribed (\\f$s=1.03$);
    =4) DCMIP eta spacing (Ullrich et al. (2012) DCMIP documentation, Appendix F.2.)
    =    with flattening parameter prescribed.
    =5) L38 40km UM specific eta spacing;
    =6) L70 80km UM specific eta spacing;
    =7) L85 85km UM specific eta spacing;
sort-key=06
title=Extrusion method
value-titles=Uniform, Quadratic, Geometric, DCMIP,
            = um_L38_29t_9s_40km, um_L70_50t_20s_80km, um_L85_50t_35s_85km
values='uniform', 'quadratic', 'geometric', 'dcmip',
      ='um_L38_29t_9s_40km', 'um_L70_50t_20s_80km', 'um_L85_50t_35s_85km'

[vertical_dimension=level_definition]
compulsory=true
title=Level boundaries
description=Boundaries of levels in ascending order
help=Positive numbers defining the edges of each level in the vertical
     dimension. The boundaries should be entered in ascending order
length=:
type=real
!macro=level_definition.Validator, level_definition.Transformer
range=0:
fail-if=len(this) != vertical_dimension=number_of_layers + 1
       =# Number of level boundaries must equal number of layers plus one
sort-key=05

[vertical_dimension=positive]
title=Positive
description=The positive direction
help=The positive direction of the vertical axis, either up or down
values=up, down
compulsory=true
sort-key=07

[vertical_dimension=units]
title=Units
description=Unit of measure
help=The unit of measure for this vertical axis is restricted to be in metres
values=m
compulsory=true
sort-key=08
"""  # noqa (disables line length error from pycodestyle)
    num = 1001
    for level in levels:
        rose_meta += f"""[vertical_dimension={level}]
title={level.replace("_", " ".title())}
description=A Model Level
type=integer
range=1:
# Layer out of range
fail-if=this > vertical_dimension=number_of_layers;
sort-key=model-levels-{num}"""
        rose_meta += os.linesep
        num += 1
    return rose_meta


def add_non_spatial_dims_meta(non_spatial_dims_meta: Dict,
                              rose_meta: str) -> str:
    """Adds the Rose metadata for the non-spatial dimensions.

    :param non_spatial_dims_meta: Dictionary containing metadata describing all
                                  of the non-spatial dimensions
    :param rose_meta: String that the non-spatial dimension data will be
                      appended to
    :return rose_meta: String with non-spatial dimension data appended to it"""

    dimension_type = {"label_definition": "character",
                      "axis_definition": "real"}
    rose_meta += """
[non_spatial_dimensions]
title=Non-Spatial Dimensions
"""

    for dimension in non_spatial_dims_meta.values():

        # Dimension only needs configuring if it doesn't have a definition
        if dimension.get("label_definition", None) is None and \
                dimension.get("axis_definition", None) is None:

            rose_meta += f"""
[non_spatial_dimensions={dimension["name"].lower().replace(" ", "_")}]
title={dimension["name"]}
description=Level definition for {dimension["name"]}
type={dimension_type[dimension["type"]]}
length=:
trigger="""
            # Trigger each field that uses this dimension
            for (section, group, field) in dimension["fields"]:
                rose_meta += f"""
       =field_config:{section}:{group}={field}: len(this) > 0 ;"""

            # Add the help text
            rose_meta += f"""
help={dimension["help"]}"""
            if "units" in dimension:
                rose_meta += f"""
    =Units: {dimension["units"]}"""

            # List each field that uses this dimension
            rose_meta += """
    =Necessary for:"""
            for _, _, field in dimension["fields"]:
                rose_meta += f"""
    =    {field}
"""

    return rose_meta
